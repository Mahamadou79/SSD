var express = require('express');
var router = express.Router();
const asyncHandler = require('express-async-handler');
const objectCtrl = require('../controllers/object.controller');
const {ObjectID} = require('mongodb');
const _ = require('lodash');



/* GET objects listing. */
router.get('/',asyncHandler(
  async (req, res) => {
    const objects = await objectCtrl.query();
    res.json(objects);
  }
));

/* GET specific Object. */
router.get('/:id',asyncHandler(
  async (req, res) => {
    const id = req.params.id;
    if (!ObjectID.isValid(id)) {
      return res.status(404).send();    
    }

    const objects = await objectCtrl.queryById(id);
    res.json(objects);
  }
));

/* PATCH Change Object. */
/*
  Param: id
  Body: {
    command: [Options: rename, move],
    [newname],
    [newpath]
  }
*/
router.patch('/:id',asyncHandler(
  async (req, res) => {
    try{
      const id = req.params.id;
      const command = req.body.command;
      console.log(req.body);
      if (!ObjectID.isValid(id)) {
        return res.status(404).send();    
      }
      let object = null;
      if(command==='rename'){
        const newname = req.body.newname;
        object = await objectCtrl.updateName(id, newname);
      }else if(command==='move'){
        const newpath = req.body.newpath;
        object = await objectCtrl.updatePath(id, newpath);
        console.log(object);
      }
      if(object){
        res.json(object);
      } else {
        res.status(400).send('Object not changed');
      }
    } catch (e) {
      console.log(e);
      res.status(400).send(e);
    }   
  }
));

/* DELETE specific Object. */
router.delete('/:id',asyncHandler(
  async (req, res) => {
    const id = req.params.id;
    if (!ObjectID.isValid(id)) {
      return res.status(404).send();    
    }

    const object = await objectCtrl.deleteById(id);
    if(object){
      res.json(object);
    } else {
      res.status(400).send('Object not changed');
    }
  }
));
module.exports = router;